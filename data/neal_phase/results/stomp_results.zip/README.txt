Contents:
stomp-alpha50-sigma12-band1-25-refFrame200-withlarge.avi
stomp-alpha50-sigma12-band1-25-refFrame200-withoutlarge.avi

This zip file contains two version of the stomp file. In the one marked as "withoutlarge", large motions (the jumping boy) are not magnified. In the other, the large motions are magnified. 
